package com.example.carfinder

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.math.pow

/*
 * CarFinder - finds your car even when it is off.
 *
 * Method 1: when the phone disconnects from the car's Bluetooth, the parked
 *           GPS position is saved. Later you get distance + direction to it.
 * Method 2: scans BLE for an always-on beacon (AirTag-like tracker, OBD dongle,
 *           cheap BLE tag) hidden in the car and shows signal strength.
 */

private const val PREFS = "carfinder"

fun prefs(c: Context): SharedPreferences = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

// ---------- Saves parked location when the car's Bluetooth disconnects ----------
class CarDisconnectReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_DISCONNECTED) return
        val dev: BluetoothDevice = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
        val p = prefs(context)
        if (dev.address != p.getString("car_mac", null)) return

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time } ?: return

        p.edit()
            .putFloat("lat", loc.latitude.toFloat())
            .putFloat("lng", loc.longitude.toFloat())
            .putLong("time", System.currentTimeMillis())
            .apply()
    }
}

// ---------- UI ----------
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var beaconInput: EditText
    private val handler = Handler(Looper.getMainLooper())
    private var scanner: BluetoothLeScanner? = null
    private var scanCb: ScanCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            prefs(this).edit().putString("crash", android.util.Log.getStackTraceString(e).take(1500)).commit()
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; setOnClickListener { try { action() } catch (t: Throwable) { output.text = "Error: $t" } }; root.addView(this)
        }
        beaconInput = EditText(this).apply {
            hint = "Beacon MAC (optional), e.g. AA:BB:CC:DD:EE:FF"
            setText(prefs(context).getString("beacon_mac", ""))
        }
        root.addView(beaconInput)
        output = TextView(this).apply { textSize = 16f }

        button("1. Pick my car's Bluetooth") { pickCar() }
        button("2. Where did I park?") { showParked() }
        button("3. Scan for car beacon") { scanBeacon() }
        button("4. Scan nearby vehicles") { scanVehicles() }
        root.addView(output)
        setContentView(ScrollView(this).apply { addView(root) })

        ensurePerms()
        prefs(this).getString("crash", null)?.let {
            output.text = "Last crash:\n$it"
            prefs(this).edit().remove("crash").apply()
        }
    }

    private fun fgPerms(): List<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_SCAN
        }
        return p
    }

    private fun hasAll(list: List<String>) =
        list.all { ActivityCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun ensurePerms(): Boolean {
        if (hasAll(fgPerms())) return true
        ActivityCompat.requestPermissions(this, fgPerms().toTypedArray(), 1)
        output.text = "Allow the permissions, then tap the button again."
        return false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Background location must be requested separately from the others
        if (requestCode == 1 && hasAll(fgPerms()) && Build.VERSION.SDK_INT >= 29 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    // Choose which paired device is the car
    @SuppressLint("MissingPermission")
    private fun pickCar() {
        if (!ensurePerms()) return
        val bonded = adapter()?.bondedDevices?.toList().orEmpty()
        if (bonded.isEmpty()) { output.text = "No paired Bluetooth devices. Pair with your car first."; return }
        val names = bonded.map { "${it.name} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Select your car")
            .setItems(names) { _, i ->
                prefs(this).edit().putString("car_mac", bonded[i].address).apply()
                output.text = "Car set to ${bonded[i].name}.\nParking will be saved when you disconnect from it."
            }.show()
    }

    // Distance + direction to saved parking spot
    @SuppressLint("MissingPermission")
    private fun showParked() {
        if (!ensurePerms()) return
        val p = prefs(this)
        if (!p.contains("lat")) { output.text = "No parking spot saved yet. Pick your car, then drive and park."; return }
        val parked = Location("saved").apply { latitude = p.getFloat("lat", 0f).toDouble(); longitude = p.getFloat("lng", 0f).toDouble() }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val here = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (here == null) { output.text = "Can't get your location. Turn on GPS."; return }

        val dist = here.distanceTo(parked).toInt()
        val bearing = (here.bearingTo(parked) + 360) % 360
        val dirs = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        val dir = dirs[((bearing + 22.5) / 45).toInt() % 8]
        val mins = (System.currentTimeMillis() - p.getLong("time", 0)) / 60000
        output.text = "Car parked ${mins} min ago\nDistance: $dist m\nDirection: $dir (${bearing.toInt()}°)"
    }

    // Scan for the always-on BLE beacon
    @SuppressLint("MissingPermission")
    private fun scanBeacon() {
        if (!ensurePerms()) return
        val mac = beaconInput.text.toString().trim().uppercase()
        scanner = adapter()?.bluetoothLeScanner
        if (scanner == null) { output.text = "Bluetooth is off."; return }
        prefs(this).edit().putString("beacon_mac", mac).apply()

        val filters = if (mac.isNotEmpty()) listOf(ScanFilter.Builder().setDeviceAddress(mac).build()) else emptyList()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        val seen = mutableMapOf<String, Int>()

        scanCb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                seen[r.device.address] = r.rssi
                val lines = seen.entries.sortedByDescending { it.value }.take(8).joinToString("\n") { (a, rssi) ->
                    // rough path-loss estimate, assumes -59 dBm at 1 m
                    val m = 10.0.pow((-59 - rssi) / 20.0)
                    "$a  ${rssi} dBm  ~%.1f m".format(m)
                }
                output.text = "Scanning (10 s)...\n$lines"
            }
        }
        scanner?.startScan(filters, settings, scanCb)
        output.text = "Scanning (10 s)..."
        handler.postDelayed({
            stopScan()
            if (seen.isEmpty()) output.text = "Beacon not found. It may be out of range (~10-30 m) or its battery is dead."
        }, 10_000)
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() { scanCb?.let { scanner?.stopScan(it) }; scanCb = null }

    // ---------- Nearby vehicle scan ----------
    private class Found(var name: String, var rssi: Int, var level: Int, var why: String)
    private var discoveryRx: BroadcastReceiver? = null

    private val carWords = listOf(
        "carplay", "android auto", "uconnect", "sync", "mylink", "entune", "hands-free car",
        "toyota", "honda", "ford", "bmw", "audi", "mercedes", "benz", "volkswagen", "skoda",
        "hyundai", "kia", "nissan", "mazda", "subaru", "tesla", "volvo", "lexus", "jeep",
        "chevrolet", "chevy", "gmc", "dodge", "suzuki", "mitsubishi", "peugeot", "renault",
        "citroen", "fiat", "porsche", "mini cooper", "land rover", "jaguar", "mg ", "tata",
        "mahindra", "byd", "obd", "elm327", "vgate", "viecar", "car "
    )

    private fun approx(rssi: Int) = 10.0.pow((-59 - rssi) / 20.0)

    @SuppressLint("MissingPermission")
    private fun scanVehicles() {
        if (!ensurePerms()) return
        val ad = adapter()
        if (ad == null || !ad.isEnabled) { output.text = "Turn Bluetooth on first."; return }
        stopScan(); stopDiscovery()
        val found = mutableMapOf<String, Found>()

        fun show(done: Boolean) {
            val cars = found.values.filter { it.level > 0 }.sortedWith(compareByDescending<Found> { it.level }.thenByDescending { it.rssi })
            val lines = cars.take(15).joinToString("\n\n") {
                val tag = if (it.level == 2) "Car system" else "Possible vehicle"
                "$tag: ${it.name.ifEmpty { "(no name)" }}\n${it.rssi} dBm, about %.0f m away\n${it.why}".format(approx(it.rssi))
            }
            val other = found.size - cars.size
            output.text = (if (done) "Scan finished.\n\n" else "Scanning (12 s)...\n\n") +
                (if (cars.isEmpty()) "No vehicles found yet.\n" else lines + "\n") +
                "\n$other other Bluetooth devices ignored."
        }

        fun add(addr: String, name: String?, rssi: Int, cls: BluetoothClass?) {
            val n = name ?: ""
            val lower = n.lowercase()
            val f = found.getOrPut(addr) { Found(n, rssi, 0, "") }
            if (n.isNotEmpty()) f.name = n
            f.rssi = rssi
            if (cls?.deviceClass == BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO) {
                f.level = 2; f.why = "Bluetooth type: car audio / infotainment"
            } else if (f.level < 1) {
                val w = carWords.firstOrNull { lower.contains(it) }
                if (w != null) { f.level = 1; f.why = "Name matches \"${w.trim()}\"" }
            }
            show(false)
        }

        // Classic Bluetooth (most car infotainment systems)
        discoveryRx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action != BluetoothDevice.ACTION_FOUND) return
                val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                val cls = i.getParcelableExtra<BluetoothClass>(BluetoothDevice.EXTRA_CLASS)
                add(d.address, d.name, rssi, cls)
            }
        }
        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(discoveryRx, filter, Context.RECEIVER_EXPORTED)
        else registerReceiver(discoveryRx, filter)
        ad.startDiscovery()

        // Bluetooth Low Energy
        scanner = ad.bluetoothLeScanner
        scanCb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                add(r.device.address, r.scanRecord?.deviceName ?: r.device.name, r.rssi, r.device.bluetoothClass)
            }
        }
        scanner?.startScan(scanCb)

        show(false)
        handler.postDelayed({ stopScan(); stopDiscovery(); show(true) }, 12_000)
    }

    @SuppressLint("MissingPermission")
    private fun stopDiscovery() {
        adapter()?.cancelDiscovery()
        discoveryRx?.let { runCatching { unregisterReceiver(it) } }
        discoveryRx = null
    }

    override fun onDestroy() { stopScan(); stopDiscovery(); super.onDestroy() }
}

/*
 * ---- AndroidManifest.xml (inside <manifest>) ----
 *
 * <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
 * <uses-permission android:name="android.permission.BLUETOOTH_SCAN"
 *     android:usesPermissionFlags="neverForLocation"/>
 * <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
 * <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
 * <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
 * <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION"/>
 *
 * ---- inside <application> ----
 *
 * <activity android:name=".MainActivity" android:exported="true">
 *     <intent-filter>
 *         <action android:name="android.intent.action.MAIN"/>
 *         <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent-filter>
 * </activity>
 *
 * <receiver android:name=".CarDisconnectReceiver" android:exported="true">
 *     <intent-filter>
 *         <action android:name="android.bluetooth.device.action.ACL_DISCONNECTED"/>
 *     </intent-filter>
 * </receiver>
 *
 * ---- build.gradle dependency ----
 * implementation "androidx.appcompat:appcompat:1.7.0"
 */
